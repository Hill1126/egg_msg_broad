// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportLoginChecker = require('../../../app/middleware/loginChecker');
import ExportResponseHandler = require('../../../app/middleware/responseHandler');

declare module 'egg' {
  interface IMiddleware {
    loginChecker: typeof ExportLoginChecker;
    responseHandler: typeof ExportResponseHandler;
  }
}
