// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAuth = require('../../../app/controller/auth');
import ExportComment = require('../../../app/controller/comment');
import ExportUser = require('../../../app/controller/user');

declare module 'egg' {
  interface IController {
    auth: ExportAuth;
    comment: ExportComment;
    user: ExportUser;
  }
}
